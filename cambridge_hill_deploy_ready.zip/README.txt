
Cambridge Hill — Full Website Package
====================================

What is included:
- index.html (interactive modern site with Purple & Gold theme)
- assets/ (images used on the site)
- backend/ (sample Node/Express server to receive admissions and create Razorpay orders)

How to use the website:
1. Unzip the package and open `index.html` in a browser to preview the site locally.
2. Replace images in `assets/` with your real photos if you like (keep same file names or update index.html paths).
3. To accept real admissions on a server, deploy the `backend/` sample (instructions below).

Backend (sample Node/Express):
------------------------------
This is a minimal demo server. It uses in-memory storage and a Razorpay library to create orders.
1. cd backend
2. npm install
3. Set environment variables: RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET
4. npm start
5. The server listens on port 4000 by default.
6. POST /api/admissions with JSON admission data to store submissions on server.
7. POST /api/create-order with {amount: 50000} to create a Razorpay order (amount in paise).

Important security notes:
- Do not commit your Razorpay secret keys to source control. Use environment variables on the server.
- For production, validate and sanitize file uploads. Consider storing photos on S3 and saving URLs in your DB.
- Use HTTPS in production.

Want me to:
- Deploy this backend on a free service (Railway.app / Render / Replit) and connect the website to it?
- Replace placeholder images with AI-generated realistic photos (I can generate 6 photos: play area, teacher reading, classroom, STEAM, library, campus)?
- Wire Razorpay checkout code into the site (client-side) so it works with the backend sample?

Reply which of the above you'd like me to do next and I'll proceed.
