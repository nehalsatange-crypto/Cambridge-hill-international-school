
// Sample Express server to receive admissions and create Razorpay orders.
// IMPORTANT: This is a sample. Replace RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET with your keys (store secrets securely).
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const Razorpay = require('razorpay');

const app = express();
app.use(cors());
app.use(bodyParser.json({limit: '10mb'}));

// Load from environment in production
const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || 'RAZORPAY_KEY_ID';
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || 'RAZORPAY_KEY_SECRET';

const razorpay = new Razorpay({
  key_id: RAZORPAY_KEY_ID,
  key_secret: RAZORPAY_KEY_SECRET
});

// Simple in-memory storage (demo)
const submissions = [];

app.post('/api/admissions', (req, res) => {
  const data = req.body;
  // validate minimal fields
  if(!data.stuName || !data.parentName || !data.mobile){
    return res.status(400).json({error: 'Missing required fields'});
  }
  const id = 'adm_' + Date.now();
  const record = Object.assign({id, createdAt: new Date().toISOString()}, data);
  submissions.unshift(record);
  return res.json({success:true, id});
});

// Create Razorpay order (demo, returns order id to client)
app.post('/api/create-order', async (req, res) => {
  const {amount, currency='INR', receipt='receipt#1'} = req.body;
  try {
    const options = {
      amount: amount, // amount in paise for INR
      currency,
      receipt,
      payment_capture: 1
    };
    const order = await razorpay.orders.create(options);
    res.json({order});
  } catch (err){
    console.error(err);
    res.status(500).json({error: 'Could not create order', details: err.message});
  }
});

app.get('/api/submissions', (req, res) => {
  res.json({submissions});
});

const port = process.env.PORT || 4000;
app.listen(port, ()=> console.log('Server running on port', port));
