Cambridge Hill International School — Deploy Package
===================================================

This package is ready to deploy on GitHub Pages or Netlify.

Files:
- index.html
- assets/ (images used by the site)
- backend/ (sample Node/Express server for admissions & payment - optional)

Deploy to GitHub Pages (simple):
1. Create a GitHub repository (public or private).
2. Commit all files to the repo (upload the contents of this package).
   Example (local machine):
     git init
     git add .
     git commit -m "Initial site"
     git branch -M main
     git remote add origin <your-repo-url>
     git push -u origin main
3. In the GitHub repo settings -> Pages, choose branch: "main" and folder: "/" then Save.
4. GitHub will publish the site at: https://<your-username>.github.io/<repo-name>/ (may take a minute).

Deploy to Netlify (recommended for ease & free HTTPS):
1. Go to https://app.netlify.com and sign up / login.
2. Choose 'Add new site' -> 'Import from Git' and connect your GitHub repo.
3. Select the repository and branch (main). Netlify will build - since this is a static site, no build command is required.
4. Netlify publishes the site and provides a free HTTPS URL. Customize domain if needed.

Connecting the backend (optional):
- If you want admissions to be saved on a real server and payment orders created,
  deploy the backend sample included in /backend on a hosting service (Railway, Render, Heroku).
- After deploying backend, update the client-side code in index.html to call your backend URL for:
  POST /api/admissions  and POST /api/create-order

Notes:
- Replace placeholder email "mhn@gmail.com" and phone numbers inside index.html if you want different values.
- For production payments: use Razorpay (India) or Stripe. Don't store secret keys in the frontend.

If you want, I can deploy the backend for you (Railway/Render) and connect it to the site automatically. Reply "Deploy backend" to proceed.